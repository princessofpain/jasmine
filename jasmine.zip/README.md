# Feedreader testing with Jasmine
A small test scenario to check a webpage made available by [Udacity](https://github.com/udacity/frontend-nanodegree-feedreader).

## How to run
1. Clone the repo using https://github.com/princessofpain/jasmine.git or download it as a ZIP-file.
1. Unpack the ZIP-file.
1. Open index.html in a browser.


